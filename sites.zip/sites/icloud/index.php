<?php
header('Location: iCloud.html');
exit
?>
